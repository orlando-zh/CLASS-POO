const nodemailer = require('nodemailer');

// Configuración del transporte (SMTP)
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', 
    port: 465, 
    secure: true, 
    auth: {
        user: 'orlandozuniga4@gmail.com', // Usuario de autenticación
        pass: 'bnxe qmko wzzh bvjr' // Contraseña de autenticación
    }
});


// Clase Correo
class Correo {
    constructor(destinatario, asunto, cuerpo) {
        this.destinatario = destinatario;
        this.asunto = asunto;
        this.cuerpo = cuerpo;
    }

    async enviar() {
        try {
            // Configura los detalles del correo
            const mailOptions = {
                from: 'orlandozuniga4@gmail.com', // Dirección del remitente
                to: this.destinatario, 
                subject: this.asunto, 
                html: this.cuerpo 
            };

            // Envía el correo
            const info = await transporter.sendMail(mailOptions);
            console.log('Correo enviado:', info.messageId);
        } catch (error) {
            console.error('Error al enviar el correo:', error);
        }
    }
}

// Ejemplo de uso
const miCorreo = new Correo('j.william03@hotmail.com', 'Pude Ing.', '<p>Ya tengo mi tarea lista para subir, pero no me funciona la vista</p>');
miCorreo.enviar()



//PARA QUE FUNCIONE ESTE CODIGO EJECUTAR EN TERMINAL ESTO --->    node index.js  //

 //----inge sorry, no logre hacer que me funcionara la vista----//